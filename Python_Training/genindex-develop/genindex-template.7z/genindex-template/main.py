#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import genlib as gm

def main():
	gm.main()

if __name__ == '__main__':
	main()
